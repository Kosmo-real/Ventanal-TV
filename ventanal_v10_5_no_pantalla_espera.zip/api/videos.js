
const STRICT_FAMILY_SLOTS = new Set(['manana','barrio','sobremesa']);
const FAMILY_REQUIRED = /(concurso|preguntas|respuestas|trivia|cultura general|game show|juego|juegos|talento|talentos|competencia familiar|desaf[ií]o familiar|kids|niños|ninos|familia|familiar)/i;
const FAMILY_REJECT = /(reality|reality show|pareja|parejas|dating|citas|novio|novia|infidel|adulter|divor|paternidad|embarazo|sexo|sexual|er[oó]tic|desnud|onlyfans|caso cerrado|tribunal|juicio|court|true crime|crimen|asesin|homicid|violencia|pelea|far[aá]ndula|chisme|celebrity gossip|casino|apuestas|18\+|adultos?|k[aä]mpferin|kampf der realitystars)/i;

function strictFamilyCandidate(item){
  const txt = `${item?.title||''} ${item?.description||''} ${item?.channelTitle||''} ${item?.snippet?.title||''} ${item?.snippet?.description||''} ${item?.snippet?.channelTitle||''}`;
  return FAMILY_REQUIRED.test(txt) && !FAMILY_REJECT.test(txt);
}

const BROAD_FAMILY_POSITIVE=/(familia|familiar|concurso|trivia|preguntas|juego|juegos|talento|cultura general|entretenimiento|entretención|humor familiar|música familiar|deporte|ciencia|kids|niños|ninos)/i;
function broadFamilyCandidate(item){
  const txt=`${item?.title||''} ${item?.description||''} ${item?.channelTitle||''} ${item?.snippet?.title||''} ${item?.snippet?.description||''} ${item?.snippet?.channelTitle||''}`;
  return BROAD_FAMILY_POSITIVE.test(txt) && !FAMILY_REJECT.test(txt);
}



const FAMILY_GAME=/concurso|preguntas|respuestas|trivia|cultura general|juegos familiares|game show|talentos|desafío familiar|desafio familiar|competencia familiar/i;

function externalLiveFeeds(slot){
  try{
    const raw=process.env.VENTANAL_LIVE_FEEDS_JSON;
    if(!raw) return [];
    const all=JSON.parse(raw);
    const list=Array.isArray(all)?all:(all?.[slot]||all?.default||[]);
    return (Array.isArray(list)?list:[]).filter(x=>x && x.url && (!x.slot || x.slot===slot));
  }catch{return []}
}


function isoDurationMinutes(iso='PT0S'){
  const m = String(iso).match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if(!m) return 0;
  return (Number(m[1]||0)*1440)+(Number(m[2]||0)*60)+Number(m[3]||0)+(Number(m[4]||0)/60);
}
function durationFitScore(minutes, target){
  if(!minutes || !target) return 0;
  const d = Math.abs(minutes-target);
  // Prefer close durations; a slightly longer video is better than a much shorter one.
  let score = Math.max(-80, 90 - d*2);
  if(minutes >= target && minutes <= target*1.20) score += 20;
  return score;
}

const SEARCHES = {
  noticias:['noticias Chile televisión en vivo','informativo Chile en vivo'],
  manana:['concurso familiar matinal en vivo español','juegos preguntas familiares en vivo español','game show familiar divertido en vivo español'],
  barrio:['concurso familiar preguntas respuestas en vivo español','trivia familiar cultura general en vivo español','game show familiar juegos divertidos en vivo español','competencia talentos familiar en vivo español'],
  sobremesa:['concurso familiar preguntas respuestas en vivo español','juegos familiares televisión en vivo español','trivia cultura general familiar en vivo español','talentos competencia familiar en vivo español'],
  cine:['entretenimiento familiar televisión en vivo español','show familiar en vivo español'],
  comedia:['humor familiar televisión en vivo español','comedia familiar en vivo español'],
  musica:['música familiar televisión en vivo','festival música en vivo español'],
  conversa:['entretención familiar televisión en vivo español','concurso familiar TV en vivo'],
  curiosidad:['ciencia entretenimiento familiar en vivo español','juegos cultura general en vivo español'],
  quedice:['Qué Dice Chile en vivo','Qué Dice Chile Martín Cárcamo en vivo'],
  extremos:['deportes extremos en vivo','surf skate BMX MTB snowboard live'],
  deportes:['deportes en vivo español','competencia deportiva en vivo'],
  noche:['game show familiar en vivo español','show entretenimiento familiar en vivo español'],
  madrugada:['entretenimiento familiar en vivo español','música familiar en vivo español'],
  kosmo:['Kosmo Studios en vivo','tecnología ciencia entretenimiento en vivo español']
};
const ONDEMAND = {
 'kids-bluey':['Bluey Español canal oficial episodios','Bluey official Spanish'],
 'kids-pocoyo':['Pocoyo Español canal oficial episodios','Pocoyo official Spanish'],
 'kids-danny':['Danny Go official kids songs learning','Danny Go español niños'],
 'kids-sesamo':['Plaza Sésamo oficial español','Sesame Street Spanish official'],
 'kids-music':['canciones infantiles educativas oficial español','kids songs learning official Spanish'],
 'kids-stories':['cuentos infantiles oficial español','kids stories official Spanish'],
 'kids-night':['cuentos para dormir niños oficial español','bedtime stories kids official Spanish'],
 'cine-pirates':['Pirates of the Caribbean official trailer Disney'],
 'cine-harry':['Harry Potter official trailer Warner Bros'],
 'cine-minions':['Minions official trailer Illumination'],
 'cine-gru':['Despicable Me official trailer Illumination'],
 'cine-monsters':['Monsters Inc official trailer Pixar Disney']
};
const LISTA_KOSMO='UUM3D8RJhXv6_u6jFWl1-Org';
const MAL=/podcast|radio|tertulia|webinar|reunión|reunion|conferencia|charla|debate|stream personal|oración|oracion|culto|misa|lofi|relax|adult|adultos|18\+|sexual|sexo|porn|erótico|erotico|desnud|onlyfans|casino|apuestas|caso cerrado|court show|tribunal|juicio|divorcio|infidelidad|adulterio|paternidad|maury|reality de parejas|reality show adultos|citas|dating|novios|embarazo|crimen real|true crime|asesinato|violencia gráfica|violencia grafica/i;
const BUENO=/tv|televisi[oó]n|canal|matinal|concurso|game show|humor|comedia|show|m[uú]sica|concierto|festival|deporte|espect[aá]culo/i;

function hash(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function isoSeconds(iso='PT0S'){const m=iso.match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);return m?(+m[1]||0)*86400+(+m[2]||0)*3600+(+m[3]||0)*60+(+m[4]||0):0}
async function yt(path,params,key){
  const u=new URL(`https://www.googleapis.com/youtube/v3/${path}`);
  u.search=new URLSearchParams({...params,key}).toString();
  const r=await fetch(u); const d=await r.json();
  if(!r.ok) throw Object.assign(new Error(d?.error?.message||'YouTube API'),{status:r.status});
  return d;
}
async function buscar(q,key){
  const d=await yt('search',{part:'snippet',type:'video',eventType:'live',q,maxResults:'25',order:'viewCount',
    relevanceLanguage:'es',regionCode:'CL',safeSearch:'moderate',videoEmbeddable:'true',videoSyndicated:'true'},key);
  return (d.items||[]).map(x=>({videoId:x.id?.videoId,title:x.snippet?.title||'En vivo',
    channel:x.snippet?.channelTitle||'',isLive:true})).filter(x=>x.videoId);
}

async function buscarGrabadoSeguro(q,key){
 const p=new URLSearchParams({
  part:'snippet',type:'video',q,maxResults:'20',safeSearch:'strict',
  videoEmbeddable:'true',videoSyndicated:'true',relevanceLanguage:'es',key
 });
 const r=await fetch(`https://www.googleapis.com/youtube/v3/search?${p}`);
 if(!r.ok) return [];
 const d=await r.json();
 return (d.items||[]).map(x=>({
   videoId:x.id?.videoId,title:x.snippet?.title||'',description:x.snippet?.description||'',
   channelTitle:x.snippet?.channelTitle||'',isLive:false
 })).filter(x=>x.videoId).filter(broadFamilyCandidate);
}


async function buscarVod(q,key,kids=false){
  const d=await yt('search',{part:'snippet',type:'video',q,maxResults:'20',order:'relevance',
    relevanceLanguage:kids?'es':'en',regionCode:'CL',safeSearch:kids?'strict':'moderate',videoEmbeddable:'true',videoSyndicated:'true'},key);
  return (d.items||[]).map(x=>({videoId:x.id?.videoId,title:x.snippet?.title||'Video',
    channel:x.snippet?.channelTitle||'',isLive:false})).filter(x=>x.videoId);
}
function ordenar(xs,slot){
  const SLOT_GOOD={
    noticias:/noticias|informativo|24 horas|prensa/i,
    manana:/matinal|magazine|entretenci[oó]n|concurso|show|televisi[oó]n|tv/i,
    barrio:/viajes|cultura|regiones|turismo|documental|televisi[oó]n|tv/i,
    sobremesa:/concurso|game show|entretenci[oó]n|humor|show|televisi[oó]n|tv/i,
    cine:/cine|pel[ií]cula|espect[aá]culo|cultura|televisi[oó]n|tv/i,
    comedia:/humor|comedia|stand.?up|festival|show/i,
    musica:/m[uú]sica|concierto|festival|show/i,
    conversa:/entrevista|magazine|programa|televisi[oó]n|tv/i,
    curiosidad:/ciencia|tecnolog[ií]a|documental|cultura|televisi[oó]n|tv/i,
    deportes:/deporte|f[uú]tbol|tenis|partido|competencia|tv/i,
    extremos:/deportes extremos|surf|skate|snowboard|bmx|mountain bike|mtb|escalada|kayak|aventura|outdoor/i,
    quedice:/qué dice chile|que dice chile|canal 13|13.cl/i,
    noche:/entretenci[oó]n|show|humor|m[uú]sica|televisi[oó]n|tv/i,
    madrugada:/m[uú]sica|cultura|documental|televisi[oó]n|tv/i
  };
  const wanted=SLOT_GOOD[slot]||BUENO;

  return [...new Map(xs.map(x=>[x.videoId,x])).values()].map(x=>{
    const t=`${x.title} ${x.channel}`; let score=0;
    if(wanted.test(t)) score+=14;
    if(BUENO.test(t)) score+=4;
    if(slot!=='noticias' && /noticias|informativo|breaking|24 horas|prensa/i.test(t)) score-=40;
    if(/Chile|chileno|chilena/i.test(t)) score+=4;
    if(MAL.test(t)) score-=30;
    return {...x,score};
  }).filter(x=>x.score>-10).sort((a,b)=>b.score-a.score);
}

async function verificarEmbebible(ids,key){
  if(!ids.length) return [];
  const u=new URL("https://www.googleapis.com/youtube/v3/videos");
  u.searchParams.set("part","status");
  u.searchParams.set("id",ids.join(","));
  u.searchParams.set("key",key);
  const r=await fetch(u); if(!r.ok) return [];
  const d=await r.json();
  return (d.items||[]).filter(x=>x.status?.embeddable===true).map(x=>({id:x.id,madeForKids:x.status?.madeForKids===true}));
}

export default async function handler(req,res){
  res.setHeader('Cache-Control','s-maxage=300, stale-while-revalidate=60');
  const key=process.env.YOUTUBE_API_KEY;
  if(!key) return res.status(500).json({error:'Falta YOUTUBE_API_KEY'});
  const slot=String(req.query.slot||'manana').toLowerCase();
  const fecha=String(req.query.fecha||new Date().toISOString().slice(0,10));
  const attempt=Math.max(0,Number(req.query.attempt||0));
  try{
    if(ONDEMAND[slot]){
      const kids=slot.startsWith('kids-');
      let found=[];
      for(const q of ONDEMAND[slot]){
        found.push(...await buscarVod(q,key,kids));
        if(found.length>=8) break;
      }
      found=[...new Map(found.map(x=>[x.videoId,x])).values()];
      const meta=await verificarEmbebible(found.map(x=>x.videoId),key);
      const ok=new Map(meta.map(x=>[x.id,x]));
      let playable=found.filter(x=>ok.has(x.videoId));
      // For Kids, prefer videos explicitly designated Made for Kids when YouTube supplies that status.
      if(kids){
        const mfk=playable.filter(x=>ok.get(x.videoId)?.madeForKids);
        if(mfk.length) playable=mfk;
      }
      if(!playable.length) return res.status(404).json({error:'No hay contenido reproducible disponible ahora'});
      const pick=playable[hash(`${fecha}|${slot}`)%Math.min(playable.length,10)];
      return res.status(200).json({...pick,slot,madeForKids:ok.get(pick.videoId)?.madeForKids||false});
    }
    if(slot==='kosmo'){
      const d=await yt('playlistItems',{part:'snippet,contentDetails',playlistId:LISTA_KOSMO,maxResults:'50'},key);
      let c=(d.items||[]).map(x=>({videoId:x.contentDetails?.videoId,title:x.snippet?.title||'Kosmo Studios',
        channel:'Kosmo Studios',isLive:false})).filter(x=>x.videoId);
      if(!c.length) return res.status(404).json({error:'No hay videos de Kosmo Studios'});
      const meta=await yt('videos',{part:'contentDetails,status',id:c.map(x=>x.videoId).join(',')},key);
      const by=new Map((meta.items||[]).map(v=>[v.id,{durationSeconds:isoSeconds(v.contentDetails?.duration),embeddable:v.status?.embeddable!==false}]));
      c=c.map(x=>({...x,...(by.get(x.videoId)||{})})).filter(x=>x.embeddable);
      if(!c.length) return res.status(404).json({error:'No hay videos reproducibles de Kosmo Studios'});
      return res.status(200).json({...c[hash(fecha)%c.length],date:fecha,slot,source:'kosmo'});
    }
    const external=externalLiveFeeds(slot);
    if(external.length){
      const ext=external[(hash(`${fecha}|${slot}`)+attempt)%external.length];
      return res.status(200).json({streamUrl:ext.url,streamType:ext.type||'hls',isLive:true,date:fecha,slot});
    }
    let acumulados=[];
    for(const q of (SEARCHES[slot]||SEARCHES.noche)){
      acumulados.push(...await buscar(q,key));
      if(ordenar(acumulados,slot).length>=3) break;
    }
    let candidatos=ordenar(acumulados,slot);
    if(fallbackOnly && STRICT_FAMILY_SLOTS.has(slot)) candidatos=[];
    if(STRICT_FAMILY_SLOTS.has(slot)) candidatos=candidatos.filter(strictFamilyCandidate);
    if(!candidatos.length && slot!=='quedice' && !STRICT_FAMILY_SLOTS.has(slot)) candidatos=ordenar(await buscar('televisión familiar entretenimiento en vivo español',key),slot);
    if(!candidatos.length) return res.status(404).json({error:'No hay una señal televisiva entretenida disponible ahora'});
    const pool=candidatos.slice(0,Math.min(12,candidatos.length));
    const ok=await verificarEmbebible(pool.map(x=>x.videoId),key);
    const okIds=new Set(ok.map(x=>x.id));
    const verified=pool.filter(x=>okIds.has(x.videoId));
    if(!verified.length) return res.status(404).json({error:'No hay señal embebible disponible ahora'});
    const pick=verified[(hash(`${fecha}|${slot}`)+attempt)%verified.length];
    return res.status(200).json({videoId:pick.videoId,isLive:pick.isLive!==false,date:fecha,slot});
  }catch(e){return res.status(e.status||500).json({error:'YouTube API',detail:e.message})}
}
