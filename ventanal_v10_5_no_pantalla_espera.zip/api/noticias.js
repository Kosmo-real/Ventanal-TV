const API='https://freenewsapi.ai/v1/search';
const BLOCK=/sexo|sexual|porn|er[oó]tic|desnud|onlyfans|casino|apuesta|suicid|gore/i;
const PRIORITY=/chile|santiago|regi[oó]n|econom[ií]a|ciencia|tecnolog[ií]a|cultura|deporte|f[uú]tbol|tenis|educaci[oó]n|salud|transporte|clima/i;

function clean(s=''){return String(s).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim()}
function category(s=''){
  s=s.toLowerCase();
  if(/f[uú]tbol|tenis|deporte|partido|campeonato/.test(s)) return 'Deportes';
  if(/econom|d[oó]lar|mercado|empresa|empleo|banco/.test(s)) return 'Economía';
  if(/ciencia|tecnolog|innovaci|espacio|universidad/.test(s)) return 'Ciencia y tecnología';
  if(/m[uú]sica|cine|cultura|festival|televisi[oó]n|actor|cantante/.test(s)) return 'Cultura y entretención';
  return 'Chile';
}
async function pull(params){
  const u=new URL(API); Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,v));
  const r=await fetch(u,{headers:{'User-Agent':'VentanalTV/1.0'}});
  if(!r.ok) throw new Error(`Servidor de noticias HTTP ${r.status}`);
  return r.json();
}
export default async function handler(req,res){
  res.setHeader('Cache-Control','s-maxage=600, stale-while-revalidate=1800');
  try{
    const d=await pull({tld:'cl',lang:'es',date:'today',sort:'date',size:'50'});
    let rows=(d.results||[]).filter(x=>x.title&&!BLOCK.test(`${x.title} ${x.description||''}`));
    rows.sort((a,b)=>{
      const ap=PRIORITY.test(`${a.title} ${a.description||''}`)?1:0,bp=PRIORITY.test(`${b.title} ${b.description||''}`)?1:0;
      return bp-ap || new Date(b.published_at)-new Date(a.published_at);
    });
    const seen=new Set(), noticias=[];
    for(const x of rows){
      const key=clean(x.title).toLowerCase().replace(/[^a-záéíóúñ0-9 ]/gi,'').slice(0,70);
      if(seen.has(key)) continue; seen.add(key);
      const titulo=clean(x.title), desc=clean(x.description||'');
      noticias.push({
        id:x.id||key, titulo, bajada:desc.slice(0,240), cuerpo:'',
        fuente:clean(x.sitename||x.host||'Fuente de noticias'), fuente_url:x.url||'',
        fecha:x.published_at||new Date().toISOString(), categoria:category(`${titulo} ${desc}`)
      });
      if(noticias.length>=10) break;
    }
    if(!noticias.length) throw new Error('El servidor no devolvió noticias recientes de Chile');
    return res.status(200).json({noticias,motor:'servidor-automatico',actualizado:new Date().toISOString()});
  }catch(e){return res.status(502).json({error:'Noticias automáticas',detail:e.message})}
}
